//
//  ShareSDKForANETests.m
//  ShareSDKForANETests
//
//  Created by 冯 鸿杰 on 14-3-13.
//  Copyright (c) 2014年 掌淘科技. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface ShareSDKForANETests : XCTestCase

@end

@implementation ShareSDKForANETests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
