package cn.sharesdk.ane.apshare;

import cn.sharesdk.alipay.share.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity{
   
}
